module ActiveSupport
  FrozenObjectError = RuntimeError
end
