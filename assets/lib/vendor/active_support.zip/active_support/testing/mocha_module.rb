module ActiveSupport
  module Testing
    module MochaModule
      begin
        require 'mocha_standalone'
        include Mocha::API

        def before_setup
          mocha_setup
          super
        end

        def after_teardown
          super
          mocha_verify
          mocha_teardown
        end
      rescue LoadError
      end
    end
  end
end
